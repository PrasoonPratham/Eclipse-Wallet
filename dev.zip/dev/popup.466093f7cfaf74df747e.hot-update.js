"use strict";
globalThis["webpackHotUpdate_coral_xyz_app_extension"]("popup",{},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("96b9d42f005cc1a2015a")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=popup.466093f7cfaf74df747e.hot-update.js.map