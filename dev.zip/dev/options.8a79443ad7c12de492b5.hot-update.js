"use strict";
globalThis["webpackHotUpdate_coral_xyz_app_extension"]("options",{},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("30fc5321f25aa99fb4cf")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=options.8a79443ad7c12de492b5.hot-update.js.map