"use strict";
globalThis["webpackHotUpdate_coral_xyz_app_extension"]("options",{},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("bf7da70db41c76181ad3")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=options.96b9d42f005cc1a2015a.hot-update.js.map