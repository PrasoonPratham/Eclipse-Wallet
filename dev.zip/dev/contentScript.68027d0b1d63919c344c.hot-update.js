"use strict";
globalThis["webpackHotUpdate_coral_xyz_app_extension"]("contentScript",{},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("ec8f12ea66e0219072e1")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=contentScript.68027d0b1d63919c344c.hot-update.js.map