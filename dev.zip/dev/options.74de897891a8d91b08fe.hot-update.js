"use strict";
globalThis["webpackHotUpdate_coral_xyz_app_extension"]("options",{},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("d60f0f464081430c3fa6")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=options.74de897891a8d91b08fe.hot-update.js.map