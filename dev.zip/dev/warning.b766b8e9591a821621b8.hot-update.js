"use strict";
globalThis["webpackHotUpdate_coral_xyz_app_extension"]("warning",{},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("2e3a586c181cff781e0c")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=warning.b766b8e9591a821621b8.hot-update.js.map