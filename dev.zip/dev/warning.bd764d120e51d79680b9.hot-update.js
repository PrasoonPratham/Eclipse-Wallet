"use strict";
globalThis["webpackHotUpdate_coral_xyz_app_extension"]("warning",{},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("466093f7cfaf74df747e")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=warning.bd764d120e51d79680b9.hot-update.js.map