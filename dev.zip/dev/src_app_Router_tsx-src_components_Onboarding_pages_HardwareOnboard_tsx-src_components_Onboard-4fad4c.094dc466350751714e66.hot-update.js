globalThis["webpackHotUpdate_coral_xyz_app_extension"]("src_app_Router_tsx-src_components_Onboarding_pages_HardwareOnboard_tsx-src_components_Onboard-4fad4c",{

/***/ "./src/components/Unlocked/Settings/Preferences/Solana/ConnectionSwitch.tsx":
/*!**********************************************************************************!*\
  !*** ./src/components/Unlocked/Settings/Preferences/Solana/ConnectionSwitch.tsx ***!
  \**********************************************************************************/
/***/ (() => {

throw new Error("Module build failed (from ../../node_modules/swc-loader/src/index.js):\nError: \n  \u001b[31mx\u001b[0m Unexpected token `Devnet`. Expected ... , *,  (, [, :, , ?, =, an identifier, public, protected, private, readonly, <.\n    ,-[\u001b[36;1;4m/Users/pratham/Documents/GitHub/backpack/packages/app-extension/src/components/Unlocked/Settings/Preferences/Solana/ConnectionSwitch.tsx\u001b[0m:33:1]\n \u001b[2m33\u001b[0m |       onClick: () => changeNetwork(SolanaCluster.LOCALNET),\n \u001b[2m34\u001b[0m |       detail: currentUrl === SolanaCluster.LOCALNET ? <Checkmark /> : null,\n \u001b[2m35\u001b[0m |     },\n \u001b[2m36\u001b[0m |     Eclipse Devnet: {\n    : \u001b[31;1m            ^^^^^^\u001b[0m\n \u001b[2m37\u001b[0m |       onClick: () => changeNetwork(\"https://api.kiwi.eclipsenetwork.xyz:8899/\"),\n \u001b[2m38\u001b[0m |       detail:\n \u001b[2m39\u001b[0m |         currentUrl === \"https://api.kiwi.eclipsenetwork.xyz:8899/\" ? (\n    `----\n\n\nCaused by:\n    Syntax Error");

/***/ })

});