"use strict";
globalThis["webpackHotUpdate_coral_xyz_app_extension"]("background",{},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("74de897891a8d91b08fe")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=background.4f94d5aa9452c668ae22.hot-update.js.map