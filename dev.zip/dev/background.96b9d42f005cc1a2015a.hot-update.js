"use strict";
globalThis["webpackHotUpdate_coral_xyz_app_extension"]("background",{},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("bf7da70db41c76181ad3")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=background.96b9d42f005cc1a2015a.hot-update.js.map