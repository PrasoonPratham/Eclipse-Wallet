"use strict";
globalThis["webpackHotUpdate_coral_xyz_app_extension"]("contentScript",{},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("b453ddce3489c88cb59f")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=contentScript.00b142e263f02b70aecb.hot-update.js.map