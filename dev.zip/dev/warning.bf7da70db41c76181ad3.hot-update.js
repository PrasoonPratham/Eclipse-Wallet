"use strict";
globalThis["webpackHotUpdate_coral_xyz_app_extension"]("warning",{},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("1a8ec1bd42b40fecd15b")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=warning.bf7da70db41c76181ad3.hot-update.js.map