"use strict";
globalThis["webpackHotUpdate_coral_xyz_app_extension"]("contentScript",{},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("2d8e89636e18f503e27b")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=contentScript.094dc466350751714e66.hot-update.js.map